import lorthon
import time
import json

if (lorthon.py_LoRaInit("global_conf.json") == 0):
    while True:
        value = json.loads(lorthon.py_LoRaRx())
        y = json.dumps(value, indent=1)
        print (y)
        time.sleep(1)
else:
    print ("ERROR!!!!")
    
lorthon.py_LoRaStop();  

