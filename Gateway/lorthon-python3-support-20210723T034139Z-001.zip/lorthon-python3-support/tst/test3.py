import lorthon
import time
import json

if (lorthon.py_LoRaInit("global_conf.json") == 0):
    while True:
        a = lorthon.py_LoRaRx()
        b = json.loads(a)
        c = json.dumps(b['packets'])
        d = c.split('"')
        e = d[67:]
        ee = d[33:]
        f = e[:1]
        ff = ee[:1]
        g = str(f)
        gg = str(ff)
        h = g[10:]
        hh = gg[10:]
        i = h[::-1]
        ii = hh[::-1]
        j = i[2:]
        jj = ii[2:]
        k = j[::-1]
        kk = jj[::-1]
        n = bytes.fromhex(k)
        nn = bytes.fromhex(kk)
        print (n)
        print (nn)
        time.sleep(1)
        #lorthon.py_LoRaTx(915000000, 0, 0, 22, 0x03, 0x02, 1, 15, False, False, "HELLO WORLD", 11)
        #time.sleep(5)
else:
    print ("ERROR!!!!")
    
lorthon.py_LoRaStop();  

